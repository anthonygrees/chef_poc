# Cookbook:: cis-windows-ms-2016
# Recipe:: default
# Copyright:: 2019, Chef Software, Inc.
# License:: Use of this Software is subject to the terms of the Chef Online Master License and Services Agreement. You can find the latest copy of the agreement here: https://www.chef.io/online-master-agreement

return unless platform_family?('windows')

# CIS section 1 and 2
include_recipe 'cis-windows-ms-2016::account_and_local_policies'
# CIS section 9
include_recipe 'cis-windows-ms-2016::windows_firewall'
# CIS section 17
include_recipe 'cis-windows-ms-2016::advanced_auditpol_config'
# CIS section 18
include_recipe 'cis-windows-ms-2016::admin_templates_computer'
# CIS section 19
include_recipe 'cis-windows-ms-2016::admin_templates_user'
