# Cookbook:: cis-windows-ms-2016
# Recipe:: advanced_auditpol_config
# Copyright:: 2019, Chef Software, Inc.
# License:: Use of this Software is subject to the terms of the Chef Online Master License and Services Agreement. You can find the latest copy of the agreement here: https://www.chef.io/online-master-agreement

# CIS section 17
return unless platform_family?('windows')

# xccdf_org.cisecurity.benchmarks_rule_17.1.1_L1_Ensure_Audit_Credential_Validation_is_set_to_Success_and_Failure
# xccdf_org.cisecurity.benchmarks_rule_17.2.1_L1_Ensure_Audit_Application_Group_Management_is_set_to_Success_and_Failure
# xccdf_org.cisecurity.benchmarks_rule_17.2.2_L1_Ensure_Audit_Computer_Account_Management_is_set_to_Success_and_Failure
# xccdf_org.cisecurity.benchmarks_rule_17.2.4_L1_Ensure_Audit_Other_Account_Management_Events_is_set_to_Success_and_Failure
# xccdf_org.cisecurity.benchmarks_rule_17.2.5_L1_Ensure_Audit_Security_Group_Management_is_set_to_Success_and_Failure
# xccdf_org.cisecurity.benchmarks_rule_17.2.6_L1_Ensure_Audit_User_Account_Management_is_set_to_Success_and_Failure
# xccdf_org.cisecurity.benchmarks_rule_17.5.1_L1_Ensure_Audit_Account_Lockout_is_set_to_Success_and_Failure
# xccdf_org.cisecurity.benchmarks_rule_17.5.4_L1_Ensure_Audit_Logon_is_set_to_Success_and_Failure
# xccdf_org.cisecurity.benchmarks_rule_17.5.5_L1_Ensure_Audit_Other_LogonLogoff_Events_is_set_to_Success_and_Failure
# xccdf_org.cisecurity.benchmarks_rule_17.6.1_L1_Ensure_Audit_Other_Object_Access_Events_is_set_to_Success_and_Failure
# xccdf_org.cisecurity.benchmarks_rule_17.6.2_L1_Ensure_Audit_Removable_Storage_is_set_to_Success_and_Failure
# xccdf_org.cisecurity.benchmarks_rule_17.7.1_L1_Ensure_Audit_Audit_Policy_Change_is_set_to_Success_and_Failure
# xccdf_org.cisecurity.benchmarks_rule_17.8.1_L1_Ensure_Audit_Sensitive_Privilege_Use_is_set_to_Success_and_Failure
# xccdf_org.cisecurity.benchmarks_rule_17.9.1_L1_Ensure_Audit_IPsec_Driver_is_set_to_Success_and_Failure
# xccdf_org.cisecurity.benchmarks_rule_17.9.2_L1_Ensure_Audit_Other_System_Events_is_set_to_Success_and_Failure
# xccdf_org.cisecurity.benchmarks_rule_17.9.4_L1_Ensure_Audit_Security_System_Extension_is_set_to_Success_and_Failure
# xccdf_org.cisecurity.benchmarks_rule_17.9.5_L1_Ensure_Audit_System_Integrity_is_set_to_Success_and_Failure
windows_audit_policy "Audit 'Credential Validation', 'Application Group Management', 'Computer Account Management', 'Other Account Management Events', 'Security Group Management', 'User Account Management', 'Account Lockout', 'Logon', 'Other Logon/Logoff Events', 'Other Object Access Events', 'Removable Storage', 'Audit Policy Change', 'Sensitive Privilege Use', 'IPsec Driver', 'Other System Events', 'Security System Extension', 'System Integrity'" do
  action :set
  sub_category ['Credential Validation', 'Application Group Management', 'Computer Account Management', 'Other Account Management Events', 'Security Group Management', 'User Account Management', 'Account Lockout', 'Logon', 'Other Logon/Logoff Events', 'Other Object Access Events', 'Removable Storage', 'Audit Policy Change', 'Sensitive Privilege Use', 'IPsec Driver', 'Other System Events', 'Security System Extension', 'System Integrity']
  success true
  failure true
end

# xccdf_org.cisecurity.benchmarks_rule_17.3.1_L1_Ensure_Audit_PNP_Activity_is_set_to_Success
# xccdf_org.cisecurity.benchmarks_rule_17.3.2_L1_Ensure_Audit_Process_Creation_is_set_to_Success
# xccdf_org.cisecurity.benchmarks_rule_17.5.2_L1_Ensure_Audit_Group_Membership_is_set_to_Success
# xccdf_org.cisecurity.benchmarks_rule_17.5.3_L1_Ensure_Audit_Logoff_is_set_to_Success
# xccdf_org.cisecurity.benchmarks_rule_17.5.6_L1_Ensure_Audit_Special_Logon_is_set_to_Success
# xccdf_org.cisecurity.benchmarks_rule_17.7.2_L1_Ensure_Audit_Authentication_Policy_Change_is_set_to_Success
# xccdf_org.cisecurity.benchmarks_rule_17.7.3_L1_Ensure_Audit_Authorization_Policy_Change_is_set_to_Success
# xccdf_org.cisecurity.benchmarks_rule_17.9.3_L1_Ensure_Audit_Security_State_Change_is_set_to_Success
windows_audit_policy "Audit 'Plug and Play Events', 'Process Creation', 'Group Membership', 'Logoff', 'Special Logon', 'Authentication Policy Change', 'Authorization Policy Change', 'Security State Change'" do
  action :set
  sub_category ['Plug and Play Events', 'Process Creation', 'Group Membership', 'Logoff', 'Special Logon', 'Authentication Policy Change', 'Authorization Policy Change', 'Security State Change']
  success true
end
