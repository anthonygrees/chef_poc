# Cookbook:: cis-windows-ms-2016
# Recipe:: admin_templates_user
# Copyright:: 2019, Chef Software, Inc.
# License:: Use of this Software is subject to the terms of the Chef Online Master License and Services Agreement. You can find the latest copy of the agreement here: https://www.chef.io/online-master-agreement

# CIS section 19
return unless platform_family?('windows')

subkey_array = registry_get_subkeys('HKEY_USERS', ':x86_64')
subkey_array.each do |key|
  if node['level'] == 1 || node['level'] == 2
    # xccdf_org.cisecurity.benchmarks_rule_19.1.3.2_L1_Ensure_Force_specific_screen_saver_Screen_saver_executable_name_is_set_to_Enabled_scrnsave.scr
    # xccdf_org.cisecurity.benchmarks_rule_19.1.3.3_L1_Ensure_Password_protect_the_screen_saver_is_set_to_Enabled
    # xccdf_org.cisecurity.benchmarks_rule_19.1.3.1_L1_Ensure_Enable_screen_saver_is_set_to_Enabled
    # xccdf_org.cisecurity.benchmarks_rule_19.1.3.4_L1_Ensure_Screen_saver_timeout_is_set_to_Enabled_900_seconds_or_fewer_but_not_0
    registry_key "HKU\\#{key}\\Software\\Policies\\Microsoft\\Windows\\Control Panel\\Desktop" do
      values [{ name: 'SCRNSAVE.EXE', type: :string, data: 'scrnsave.scr' },
              { name: 'ScreenSaverIsSecure', type: :string, data: '1' },
              { name: 'ScreenSaveActive', type: :string, data: '1' },
              { name: 'ScreenSaveTimeOut', type: :dword, data: 900 }]
      recursive true
      action :create
    end

    # xccdf_org.cisecurity.benchmarks_rule_19.5.1.1_L1_Ensure_Turn_off_toast_notifications_on_the_lock_screen_is_set_to_Enabled
    registry_key "HKU\\#{key}\\Software\\Policies\\Microsoft\\Windows\\CurrentVersion\\PushNotifications" do
      values [{ name: 'NoToastApplicationNotificationOnLockScreen', type: :dword, data: 1 }]
      recursive true
      action :create
    end

    # xccdf_org.cisecurity.benchmarks_rule_19.7.4.1_L1_Ensure_Do_not_preserve_zone_information_in_file_attachments_is_set_to_Disabled
    # xccdf_org.cisecurity.benchmarks_rule_19.7.4.2_L1_Ensure_Notify_antivirus_programs_when_opening_attachments_is_set_to_Enabled
    registry_key "HKU\\#{key}\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Attachments" do
      values [{ name: 'SaveZoneInformation', type: :dword, data: 2 },
              { name: 'ScanWithAntiVirus', type: :dword, data: 3 }]
      recursive true
      action :create
    end

    # xccdf_org.cisecurity.benchmarks_rule_19.7.26.1_L1_Ensure_Prevent_users_from_sharing_files_within_their_profile._is_set_to_Enabled
    registry_key "HKU\\#{key}\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer" do
      values [{ name: 'NoInplaceSharing', type: :dword, data: 1 }]
      recursive true
      action :create
    end

    # xccdf_org.cisecurity.benchmarks_rule_19.7.40.1_L1_Ensure_Always_install_with_elevated_privileges_is_set_to_Disabled
    registry_key "HKU\\#{key}\\Software\\Policies\\Microsoft\\Windows\\Installer" do
      values [{ name: 'AlwaysInstallElevated', type: :dword, data: 0 }]
      recursive true
      action :create
    end

    # xccdf_org.cisecurity.benchmarks_rule_19.7.7.2_L1_Ensure_Do_not_suggest_third-party_content_in_Windows_spotlight_is_set_to_Enabled
    registry_key "HKU\\#{key}\\Software\\Policies\\Microsoft\\Windows\\CloudContent" do
      values [{ name: 'DisableThirdPartySuggestions', type: :dword, data: 1 }]
      recursive true
      action :create
    end
  end

  next unless node['level'] == 2
  # xccdf_org.cisecurity.benchmarks_rule_19.7.7.1_L1_Ensure_Configure_Windows_spotlight_on_lock_screen_is_set_to_Disabled
  # xccdf_org.cisecurity.benchmarks_rule_19.7.7.3_L2_Ensure_Do_not_use_diagnostic_data_for_tailored_experiences_is_set_to_Enabled
  # xccdf_org.cisecurity.benchmarks_rule_19.7.7.4_L2_Ensure_Turn_off_all_Windows_spotlight_features_is_set_to_Enabled
  registry_key "HKU\\#{key}\\Software\\Policies\\Microsoft\\Windows\\CloudContent" do
    values [{ name: 'ConfigureWindowsSpotlight', type: :dword, data: 2 },
            { name: 'DisableTailoredExperiencesWithDiagnosticData', type: :dword, data: 1 },
            { name: 'DisableWindowsSpotlightFeatures', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_19.6.5.1.1_L2_Ensure_Turn_off_Help_Experience_Improvement_Program_is_set_to_Enabled
  registry_key "HKU\\#{key}\\Software\\Policies\\Microsoft\\Assistance\\Client\\1.0" do
    values [{ name: 'NoImplicitFeedback', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_19.7.44.2.1_L2_Ensure_Prevent_Codec_Download_is_set_to_Enabled
  registry_key "HKU\\#{key}\\Software\\Policies\\Microsoft\\WindowsMediaPlayer" do
    values [{ name: 'PreventCodecDownload', type: :dword, data: 1 }]
    recursive true
    action :create
  end
end
