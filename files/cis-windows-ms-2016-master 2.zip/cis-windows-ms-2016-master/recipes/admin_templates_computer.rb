# Cookbook:: cis-windows-ms-2016
# Recipe:: admin_templates_computer
# Copyright:: 2019, Chef Software, Inc.
# License:: Use of this Software is subject to the terms of the Chef Online Master License and Services Agreement. You can find the latest copy of the agreement here: https://www.chef.io/online-master-agreement

# CIS section 18
return unless platform_family?('windows')

if node['level'] == 1 || node['level'] == 2
  node.default['LAPs'] = true if powershell_out('Test-Path "C:\Program Files\LAPS\CSE\AdmPwd.dll"').stdout.strip == 'True'

  # xccdf_org.cisecurity.benchmarks_rule_18.1.2.2_L1_Ensure_Allow_input_personalization_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\InputPersonalization' do
    values [{ name: 'AllowInputPersonalization', type: :dword, data: 0 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.4.1_L1_Ensure_MSS_AutoAdminLogon_Enable_Automatic_Logon_not_recommended_is_set_to_Disabled
  # xccdf_org.cisecurity.benchmarks_rule_18.4.9_L1_Ensure_MSS_ScreenSaverGracePeriod_The_time_in_seconds_before_the_screen_saver_grace_period_expires_0_recommended_is_set_to_Enabled_5_or_fewer_seconds
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon' do
    values [
      { name: 'AutoAdminLogon', type: :string, data: '0' },
      { name: 'ScreenSaverGracePeriod', type: :dword, data: 5 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.5.14.1_L1_Ensure_Hardened_UNC_Paths_is_set_to_Enabled_with_Require_Mutual_Authentication_and_Require_Integrity_set_for_all_NETLOGON_and_SYSVOL_shares
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\NetworkProvider\\HardenedPaths' do
    values [
      { name: '\\\\*\\NETLOGON', type: :string, data: 'RequireMutualAuthentication=1, RequireIntegrity=1' },
      { name: '\\\\*\\SYSVOL', type: :string, data: 'RequireMutualAuthentication=1, RequireIntegrity=1' },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.5.4.1_L1_Set_NetBIOS_node_type_to_P-node_Ensure_NetBT_Parameter_NodeType_is_set_to_0x2_2_MS_Only
  # xccdf_org.cisecurity.benchmarks_rule_18.4.6_L1_Ensure_MSS_NoNameReleaseOnDemand_Allow_the_computer_to_ignore_NetBIOS_name_release_requests_except_from_WINS_servers_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\System\\CurrentControlSet\\Services\\Netbt\\Parameters' do
    values [
      { name: 'NodeType', type: :dword, data: 2 },
      { name: 'nonamereleaseondemand', type: :dword, data: 1 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.5.4.2_L1_Ensure_Turn_off_multicast_name_resolution_is_set_to_Enabled_MS_Only
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows NT\\DNSClient' do
    values [{ name: 'EnableMulticast', type: :dword, data: 0 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.5.8.1_L1_Ensure_Enable_insecure_guest_logons_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\LanmanWorkstation' do
    values [{ name: 'AllowInsecureGuestAuth', type: :dword, data: 0 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.5.11.3_L1_Ensure_Prohibit_use_of_Internet_Connection_Sharing_on_your_DNS_domain_network_is_set_to_Enabled
  # xccdf_org.cisecurity.benchmarks_rule_18.5.11.2_L1_Ensure_Prohibit_installation_and_configuration_of_Network_Bridge_on_your_DNS_domain_network_is_set_to_Enabled
  # xccdf_org.cisecurity.benchmarks_rule_18.5.11.4_L1_Ensure_Require_domain_users_to_elevate_when_setting_a_networks_location_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\Network Connections' do
    values [
      { name: 'NC_ShowSharedAccessUI', type: :dword, data: 0 },
      { name: 'NC_AllowNetBridge_NLA', type: :dword, data: 0 },
      { name: 'NC_StdDomainUserSetLocation', type: :dword, data: 1 },
    ]
    recursive true
    action :create
  end

  if node['LAPs'] == true
    # xccdf_org.cisecurity.benchmarks_rule_18.2.1_L1_Ensure_LAPS_AdmPwd_GPO_Extension__CSE_is_installed_MS_only
    registry_key 'HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\\GPExtensions\\{D76B9641-3288-4f75-942D-087DE603E3EA}' do
      values [{ name: 'DllName', type: :string, data: 'C:\\Program Files\\LAPS\\CSE\\AdmPwd.dll' }]
      recursive true
      action :create
    end

    # xccdf_org.cisecurity.benchmarks_rule_18.2.2_L1_Ensure_Do_not_allow_password_expiration_time_longer_than_required_by_policy_is_set_to_Enabled_MS_only
    # xccdf_org.cisecurity.benchmarks_rule_18.2.3_L1_Ensure_Enable_Local_Admin_Password_Management_is_set_to_Enabled_MS_only
    # xccdf_org.cisecurity.benchmarks_rule_18.2.4_L1_Ensure_Password_Settings_Password_Complexity_is_set_to_Enabled_Large_letters__small_letters__numbers__special_characters_MS_only
    # xccdf_org.cisecurity.benchmarks_rule_18.2.5_L1_Ensure_Password_Settings_Password_Length_is_set_to_Enabled_15_or_more_MS_only
    # xccdf_org.cisecurity.benchmarks_rule_18.2.6_L1_Ensure_Password_Settings_Password_Age_Days_is_set_to_Enabled_30_or_fewer_MS_only
    registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft Services\\AdmPwd' do
      values [
        { name: 'PwdExpirationProtectionEnabled', type: :dword, data: 1 },
        { name: 'AdmPwdEnabled', type: :dword, data: 1 },
        { name: 'PasswordComplexity', type: :dword, data: 4 },
        { name: 'PasswordLength', type: :dword, data: 15 },
        { name: 'PasswordAgeDays', type: :dword, data: 30 },
      ]
      recursive true
      action :create
    end
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.3.1_L1_Ensure_Apply_UAC_restrictions_to_local_accounts_on_network_logons_is_set_to_Enabled_MS_only
  # xccdf_org.cisecurity.benchmarks_rule_18.9.6.1_L1_Ensure_Allow_Microsoft_accounts_to_be_optional_is_set_to_Enabled
  # xccdf_org.cisecurity.benchmarks_rule_18.9.86.1_L1_Ensure_Sign-in_last_interactive_user_automatically_after_a_system-initiated_restart_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' do
    values [
      { name: 'LocalAccountTokenFilterPolicy', type: :dword, data: 0 },
      { name: 'MSAOptional', type: :dword, data: 1 },
      { name: 'DisableAutomaticRestartSignOn', type: :dword, data: 1 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.3.2_L1_Ensure_Configure_SMB_v1_client_driver_is_set_to_Enabled_Disable_driver
  registry_key 'HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\mrxsmb10' do
    values [
      { name: 'Start', type: :dword, data: 4 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.3.3_L1_Ensure_Configure_SMB_v1_server_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\LanmanServer\\Parameters' do
    values [
      { name: 'SMB1', type: :dword, data: 0 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.3.4_L1_Ensure_Enable_Structured_Exception_Handling_Overwrite_Protection_SEHOP_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\kernel' do
    values [
      { name: 'DisableExceptionChainValidation', type: :dword, data: 0 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.3.5_L1_Ensure_Turn_on_Windows_Defender_protection_against_Potentially_Unwanted_Applications_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\MpEngine' do
    values [
      { name: 'MpEnablePus', type: :dword, data: 1 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.22.1.1_L1_Ensure_Turn_off_downloading_of_print_drivers_over_HTTP_is_set_to_Enabled
  # xccdf_org.cisecurity.benchmarks_rule_18.8.22.1.6_L1_Ensure_Turn_off_printing_over_HTTP_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows NT\\Printers' do
    values [
      { name: 'DisableWebPnPDownload', type: :dword, data: 1 },
      { name: 'DisableHTTPPrinting', type: :dword, data: 1 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.21.5_L1_Ensure_Turn_off_background_refresh_of_Group_Policy_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' do
    values [{ name: 'DisableBkGndGroupPolicy' }]
    recursive true
    action :delete
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.21.4_L1_Ensure_Continue_experiences_on_this_device_is_set_to_Disabled
  # xccdf_org.cisecurity.benchmarks_rule_18.8.27.1_L1_Ensure_Block_user_from_showing_account_details_on_sign-in_is_set_to_Enabled
  # xccdf_org.cisecurity.benchmarks_rule_18.9.80.1.1_L1_Ensure_Configure_Windows_Defender_SmartScreen_is_set_to_Enabled_Warn_and_prevent_bypass
  # xccdf_org.cisecurity.benchmarks_rule_18.8.27.2_L1_Ensure_Do_not_display_network_selection_UI_is_set_to_Enabled
  # xccdf_org.cisecurity.benchmarks_rule_18.8.27.3_L1_Ensure_Do_not_enumerate_connected_users_on_domain-joined_computers_is_set_to_Enabled
  # xccdf_org.cisecurity.benchmarks_rule_18.8.27.4_L1_Ensure_Enumerate_local_users_on_domain-joined_computers_is_set_to_Disabled_MS_only
  # xccdf_org.cisecurity.benchmarks_rule_18.8.27.5_L1_Ensure_Turn_off_app_notifications_on_the_lock_screen_is_set_to_Enabled
  # xccdf_org.cisecurity.benchmarks_rule_18.8.27.6_L1_Ensure_Turn_off_picture_password_sign-in_is_set_to_Enabled
  # xccdf_org.cisecurity.benchmarks_rule_18.8.27.7_L1_Ensure_Turn_on_convenience_PIN_sign-in_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\System' do
    values [
      { name: 'EnableCdp', type: :dword, data: 0 },
      { name: 'BlockUserFromShowingAccountDetailsOnSignin', type: :dword, data: 1 },
      { name: 'ShellSmartScreenLevel', type: :string, data: 'Block' },
      { name: 'EnableSmartScreen', type: :string, data: '1' },
      { name: 'DontDisplayNetworkSelectionUI', type: :dword, data: 1 },
      { name: 'DontEnumerateConnectedUsers', type: :dword, data: 1 },
      { name: 'EnumerateLocalUsers', type: :dword, data: 0 },
      { name: 'DisableLockScreenAppNotifications', type: :dword, data: 1 },
      { name: 'BlockDomainPicturePassword', type: :dword, data: 1 },
      { name: 'AllowDomainPINLogon', type: :dword, data: 0 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.28.1_L1_Ensure_Untrusted_Font_Blocking_is_set_to_Enabled_Block_untrusted_fonts_and_log_events
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows NT\\MitigationOptions' do
    values [{ name: 'MitigationOptions_FontBocking', type: :string, data: '1000000000000' }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.33.6.3_L1_Ensure_Require_a_password_when_a_computer_wakes_on_battery_is_set_to_Enabled
  # xccdf_org.cisecurity.benchmarks_rule_18.8.33.6.4_L1_Ensure_Require_a_password_when_a_computer_wakes_plugged_in_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Power\\PowerSettings\\0e796bdb-100d-47d6-a2d5-f7d2daa51f51' do
    values [
      { name: 'DCSettingIndex', type: :dword, data: 1 },
      { name: 'ACSettingIndex', type: :dword, data: 1 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.101.2_L1_Ensure_Configure_Automatic_Updates_is_set_to_Enabled
  # xccdf_org.cisecurity.benchmarks_rule_18.9.101.3_L1_Ensure_Configure_Automatic_Updates_Scheduled_install_day_is_set_to_0_-_Every_day
  # xccdf_org.cisecurity.benchmarks_rule_18.9.101.4_L1_Ensure_No_auto-restart_with_logged_on_users_for_scheduled_automatic_updates_installations_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\WindowsUpdate\\AU' do
    values [
      { name: 'NoAutoUpdate', type: :dword, data: 0 },
      { name: 'ScheduledInstallDay', type: :dword, data: 0 },
      { name: 'NoAutoRebootWithLoggedOnUsers', type: :dword, data: 0 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.101.1.3_L1_Ensure_Select_when_Quality_Updates_are_received_is_set_to_Enabled_0_days
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\WindowsUpdate' do
    values [
      { name: 'DeferQualityUpdates', type: :dword, data: 1 },
      { name: 'DeferQualityUpdatesPeriodInDays', type: :dword, data: 0 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.97.2.4_L1_Ensure_Disallow_WinRM_from_storing_RunAs_credentials_is_set_to_Enabled
  # xccdf_org.cisecurity.benchmarks_rule_18.9.97.2.1_L1_Ensure_Allow_Basic_authentication_is_set_to_Disabled
  # xccdf_org.cisecurity.benchmarks_rule_18.9.97.2.3_L1_Ensure_Allow_unencrypted_traffic_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\WinRM\\Service' do
    values [
      { name: 'DisableRunAs', type: :dword, data: 1 },
      { name: 'AllowBasic', type: :dword, data: 0 },
      { name: 'AllowUnencryptedTraffic', type: :dword, data: 0 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.97.1.3_L1_Ensure_Disallow_Digest_authentication_is_set_to_Enabled
  # xccdf_org.cisecurity.benchmarks_rule_18.9.97.1.1_L1_Ensure_Allow_Basic_authentication_is_set_to_Disabled
  # xccdf_org.cisecurity.benchmarks_rule_18.9.97.1.2_L1_Ensure_Allow_unencrypted_traffic_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\WinRM\\Client' do
    values [
      { name: 'AllowDigest', type: :dword, data: 0 },
      { name: 'AllowBasic', type: :dword, data: 0 },
      { name: 'AllowUnencryptedTraffic', type: :dword, data: 0 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.84.2_L1_Ensure_Allow_Windows_Ink_Workspace_is_set_to_Enabled_On_but_disallow_access_above_lock_OR_Disabled_but_not_Enabled_On
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\WindowsInkWorkspace' do
    values [{ name: 'AllowWindowsInkWorkspace', type: :dword, data: 0 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.60.3_L1_Ensure_Allow_indexing_of_encrypted_files_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\Windows Search' do
    values [
      { name: 'AllowIndexingEncryptedStoresOrItems', type: :dword, data: 0 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.58.3.9.1_L1_Ensure_Always_prompt_for_password_upon_connection_is_set_to_Enabled
  # xccdf_org.cisecurity.benchmarks_rule_18.8.35.1_L1_Ensure_Configure_Offer_Remote_Assistance_is_set_to_Disabled
  # xccdf_org.cisecurity.benchmarks_rule_18.8.35.2_L1_Ensure_Configure_Solicited_Remote_Assistance_is_set_to_Disabled
  # xccdf_org.cisecurity.benchmarks_rule_18.9.58.2.2_L1_Ensure_Do_not_allow_passwords_to_be_saved_is_set_to_Enabled
  # xccdf_org.cisecurity.benchmarks_rule_18.9.58.3.9.2_L1_Ensure_Require_secure_RPC_communication_is_set_to_Enabled
  # xccdf_org.cisecurity.benchmarks_rule_18.9.58.3.9.3_L1_Ensure_Set_client_connection_encryption_level_is_set_to_Enabled_High_Level
  # xccdf_org.cisecurity.benchmarks_rule_18.9.58.3.11.1_L1_Ensure_Do_not_delete_temp_folders_upon_exit_is_set_to_Disabled
  # xccdf_org.cisecurity.benchmarks_rule_18.9.58.3.11.2_L1_Ensure_Do_not_use_temporary_folders_per_session_is_set_to_Disabled
  # xccdf_org.cisecurity.benchmarks_rule_18.9.58.3.3.2_L1_Ensure_Do_not_allow_drive_redirection_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows NT\\Terminal Services' do
    values [
      { name: 'fPromptForPassword', type: :dword, data: 1 },
      { name: 'fAllowUnsolicited', type: :dword, data: 0 },
      { name: 'fAllowToGetHelp', type: :dword, data: 0 },
      { name: 'DisablePasswordSaving', type: :dword, data: 1 },
      { name: 'fEncryptRPCTraffic', type: :dword, data: 1 },
      { name: 'MinEncryptionLevel', type: :dword, data: 3 },
      { name: 'DeleteTempDirsOnExit', type: :dword, data: 1 },
      { name: 'PerSessionTempDir', type: :dword, data: 1 },
      { name: 'fDisableCdm', type: :dword, data: 1 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.52.1_L1_Ensure_Prevent_the_usage_of_OneDrive_for_file_storage_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\OneDrive' do
    values [{ name: 'DisableFileSyncNGSC', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.44.1_L1_Ensure_Block_all_consumer_Microsoft_account_user_authentication_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\MicrosoftAccount' do
    values [{ name: 'DisableUserAuth', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.30.2_L1_Ensure_Turn_off_Data_Execution_Prevention_for_Explorer_is_set_to_Disabled
  # xccdf_org.cisecurity.benchmarks_rule_18.9.8.1_L1_Ensure_Disallow_Autoplay_for_non-volume_devices_is_set_to_Enabled
  # xccdf_org.cisecurity.benchmarks_rule_18.9.30.3_L1_Ensure_Turn_off_heap_termination_on_corruption_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\Explorer' do
    values [
      { name: 'NoDataExecutionPrevention', type: :dword, data: 0 },
      { name: 'NoAutoplayfornonVolume', type: :dword, data: 1 },
      { name: 'NoHeapTerminationOnCorruption', type: :dword, data: 0 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.16.5_L1_Ensure_Toggle_user_control_over_Insider_builds_is_set_to_Disabled
  # xccdf_org.cisecurity.benchmarks_rule_18.9.16.3_L1_Ensure_Disable_pre-release_features_or_settings_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\PreviewBuilds' do
    values [
      { name: 'AllowBuildPreview', type: :dword, data: 0 },
      { name: 'EnableConfigFlighting', type: :dword, data: 0 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.16.4_L1_Ensure_Do_not_show_feedback_notifications_is_set_to_Enabled
  # xccdf_org.cisecurity.benchmarks_rule_18.9.16.3_L1_Ensure_Disable_pre-release_features_or_settings_is_set_to_Disabled
  # xccdf_org.cisecurity.benchmarks_rule_18.9.16.1_L1_Ensure_Allow_Telemetry_is_set_to_Enabled_0_-_Security_Enterprise_Only_or_Enabled_1_-_Basic
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\DataCollection' do
    values [
      { name: 'DoNotShowFeedbackNotifications', type: :dword, data: 1 },
      { name: 'EnableConfigFlighting', type: :dword, data: 0 },
      { name: 'AllowTelemetry', type: :dword, data: node['security_policy']['registry_value']['AllowTelemetry'] },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.14.1_L1_Ensure_Require_pin_for_pairing_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\Connect' do
    values [{ name: 'RequirePinForPairing', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.13.1_L1_Ensure_Turn_off_Microsoft_consumer_experiences_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\CloudContent' do
    values [{ name: 'DisableWindowsConsumerFeatures', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.10.1.1_L1_Ensure_Configure_enhanced_anti-spoofing_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Biometrics\\FacialFeatures' do
    values [{ name: 'EnhancedAntiSpoofing', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.5.14.1_L1_Ensure_Hardened_UNC_Paths_is_set_to_Enabled_with_Require_Mutual_Authentication_and_Require_Integrity_set_for_all_NETLOGON_and_SYSVOL_shares
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\NetworkProvider\\HardenedPaths' do
    values [
      { name: '\\\\*\\NETLOGON', type: :string, data: 'RequireMutualAuthentication=1, RequireIntegrity=1' },
      { name: '\\\\*\\SYSVOL', type: :string, data: 'RequireMutualAuthentication=1, RequireIntegrity=1' },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.36.1_L1_Ensure_Enable_RPC_Endpoint_Mapper_Client_Authentication_is_set_to_Enabled_MS_only
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows NT\\Rpc' do
    values [{ name: 'EnableAuthEpResolution', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.4.3_L1_Ensure_MSS_DisableIPSourceRouting_IP_source_routing_protection_level_protects_against_packet_spoofing_is_set_to_Enabled_Highest_protection_source_routing_is_completely_disabled
  # xccdf_org.cisecurity.benchmarks_rule_18.4.4_L1_Ensure_MSS_EnableICMPRedirect_Allow_ICMP_redirects_to_override_OSPF_generated_routes_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\System\\CurrentControlSet\\Services\\Tcpip\\Parameters' do
    values [
      { name: 'DisableIPSourceRouting', type: :dword, data: 2 },
      { name: 'EnableICMPRedirect', type: :dword, data: 0 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.4.2_L1_Ensure_MSS_DisableIPSourceRouting_IPv6_IP_source_routing_protection_level_protects_against_packet_spoofing_is_set_to_Enabled_Highest_protection_source_routing_is_completely_disabled
  registry_key 'HKEY_LOCAL_MACHINE\\System\\CurrentControlSet\\Services\\TCPIP6\\Parameters' do
    values [{ name: 'DisableIPSourceRouting', type: :dword, data: 2 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.5.21.1_L1_Ensure_Minimize_the_number_of_simultaneous_connections_to_the_Internet_or_a_Windows_Domain_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\WcmSvc\\GroupPolicy' do
    values [{ name: 'fMinimizeConnections', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.1.1.1_L1_Ensure_Prevent_enabling_lock_screen_camera_is_set_to_Enabled
  # xccdf_org.cisecurity.benchmarks_rule_18.1.1.2_L1_Ensure_Prevent_enabling_lock_screen_slide_show_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\Personalization' do
    values [
      { name: 'NoLockScreenCamera', type: :dword, data: 1 },
      { name: 'NoLockScreenSlideshow', type: :dword, data: 1 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.4.8_L1_Ensure_MSS_SafeDllSearchMode_Enable_Safe_DLL_search_mode_recommended_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Session Manager' do
    values [{ name: 'SafeDLLSearchMode', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.4.12_L1_Ensure_MSS_WarningLevel_Percentage_threshold_for_the_security_event_log_at_which_the_system_will_generate_a_warning_is_set_to_Enabled_90_or_less
  registry_key 'HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\Eventlog\\Security' do
    values [{ name: 'WarningLevel', type: :dword, data: 90 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.3.6_L1_Ensure_WDigest_Authentication_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\SecurityProviders\\WDigest' do
    values [{ name: 'UseLogonCredential', type: :dword, data: 0 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.3.1_L1_Ensure_Include_command_line_in_process_creation_events_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\\Audit' do
    values [{ name: 'ProcessCreationIncludeCmdLine_Enabled', type: :dword, data: 0 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.4.1_L1_Ensure_Remote_host_allows_delegation_of_non-exportable_credentials_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\CredentialsDelegation' do
    values [{ name: 'AllowProtectedCreds', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.14.1_L1_Ensure_Boot-Start_Driver_Initialization_Policy_is_set_to_Enabled_Good_unknown_and_bad_but_critical
  registry_key 'HKEY_LOCAL_MACHINE\\System\\CurrentControlSet\\Policies\\EarlyLaunch' do
    values [{ name: 'DriverLoadPolicy', type: :dword, data: 3 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.21.2_L1_Ensure_Configure_registry_policy_processing_Do_not_apply_during_periodic_background_processing_is_set_to_Enabled_FALSE
  # xccdf_org.cisecurity.benchmarks_rule_18.8.21.3_L1_Ensure_Configure_registry_policy_processing_Process_even_if_the_Group_Policy_objects_have_not_changed_is_set_to_Enabled_TRUE
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\Group Policy\\{35378EAC-683F-11D2-A89A-00C04FBBCFA2}' do
    values [
      { name: 'NoBackgroundPolicy', type: :dword, data: 0 },
      { name: 'NoGPOListChanges', type: :dword, data: 0 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.15.1_L1_Ensure_Do_not_display_the_password_reveal_button_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\CredUI' do
    values [{ name: 'DisablePasswordReveal', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.15.2_L1_Ensure_Enumerate_administrator_accounts_on_elevation_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\CredUI' do
    values [{ name: 'EnumerateAdministrators', type: :dword, data: 0 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.26.1.1_L1_Ensure_Application_Control_Event_Log_behavior_when_the_log_file_reaches_its_maximum_size_is_set_to_Disabled
  # xccdf_org.cisecurity.benchmarks_rule_18.9.26.1.2_L1_Ensure_Application_Specify_the_maximum_log_file_size_KB_is_set_to_Enabled_32768_or_greater
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\EventLog\\Application' do
    values [
      { name: 'Retention', type: :string, data: 0 },
      { name: 'MaxSize', type: :dword, data: 32768 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.26.2.1_L1_Ensure_Security_Control_Event_Log_behavior_when_the_log_file_reaches_its_maximum_size_is_set_to_Disabled
  # xccdf_org.cisecurity.benchmarks_rule_18.9.26.2.2_L1_Ensure_Security_Specify_the_maximum_log_file_size_KB_is_set_to_Enabled_196608_or_greater
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\EventLog\\Security' do
    values [
      { name: 'Retention', type: :string, data: 0 },
      { name: 'MaxSize', type: :dword, data: 196608 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.26.3.1_L1_Ensure_Setup_Control_Event_Log_behavior_when_the_log_file_reaches_its_maximum_size_is_set_to_Disabled
  # xccdf_org.cisecurity.benchmarks_rule_18.9.26.3.2_L1_Ensure_Setup_Specify_the_maximum_log_file_size_KB_is_set_to_Enabled_32768_or_greater
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\EventLog\\Setup' do
    values [
      { name: 'Retention', type: :string, data: 0 },
      { name: 'MaxSize', type: :dword, data: 32768 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.26.4.1_L1_Ensure_System_Control_Event_Log_behavior_when_the_log_file_reaches_its_maximum_size_is_set_to_Disabled
  # xccdf_org.cisecurity.benchmarks_rule_18.9.26.4.2_L1_Ensure_System_Specify_the_maximum_log_file_size_KB_is_set_to_Enabled_32768_or_greater
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\EventLog\\System' do
    values [
      { name: 'Retention', type: :string, data: 0 },
      { name: 'MaxSize', type: :dword, data: 32768 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.59.1_L1_Ensure_Prevent_downloading_of_enclosures_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Internet Explorer\\Feeds' do
    values [{ name: 'DisableEnclosureDownload', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.85.1_L1_Ensure_Allow_user_control_over_installs_is_set_to_Disabled
  # xccdf_org.cisecurity.benchmarks_rule_18.9.85.2_L1_Ensure_Always_install_with_elevated_privileges_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\Installer' do
    values [
      { name: 'EnableUserControl', type: :dword, data: 0 },
      { name: 'AlwaysInstallElevated', type: :dword, data: 0 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.95.1_L1_Ensure_Turn_on_PowerShell_Script_Block_Logging_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\PowerShell\\ScriptBlockLogging' do
    values [{ name: 'EnableScriptBlockLogging', type: :dword, data: 0 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.95.2_L1_Ensure_Turn_on_PowerShell_Transcription_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\PowerShell\\Transcription' do
    values [{ name: 'EnableTranscripting', type: :dword, data: 0 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.8.2_L1_Ensure_Set_the_default_behavior_for_AutoRun_is_set_to_Enabled_Do_not_execute_any_autorun_commands
  # xccdf_org.cisecurity.benchmarks_rule_18.9.8.3_L1_Ensure_Turn_off_Autoplay_is_set_to_Enabled_All_drives
  # xccdf_org.cisecurity.benchmarks_rule_18.9.30.4_L1_Ensure_Turn_off_shell_protocol_protected_mode_is_set_to_Disabled
  # xccdf_org.cisecurity.benchmarks_rule_18.8.22.1.5_L1_Ensure_Turn_off_Internet_download_for_Web_publishing_and_online_ordering_wizards_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer' do
    values [
      { name: 'NoAutorun', type: :dword, data: 1 },
      { name: 'NoDriveTypeAutoRun', type: :dword, data: 255 },
      { name: 'PreXPSP2ShellProtocolBehavior', type: :dword, data: 0 },
      { name: 'NoWebServices', type: :dword, data: 1 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.13.1_L1_Ensure_Turn_off_Microsoft_consumer_experiences_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\CloudContent' do
    values [{ name: 'DisableWindowsConsumerFeatures', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.76.10.1_L1_Ensure_Scan_removable_drives_is_set_to_Enabled
  # xccdf_org.cisecurity.benchmarks_rule_18.9.76.10.2_L1_Ensure_Turn_on_e-mail_scanning_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Scan' do
    values [
      { name: 'DisableRemovableDriveScanning', type: :dword, data: 0 },
      { name: 'DisableEmailScanning', type: :dword, data: 0 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.76.13.1.1_L1_Ensure_Configure_Attack_Surface_Reduction_rules_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Windows Defender Exploit Guard\\ASR' do
    values [{ name: 'ExploitGuard_ASR_Rules', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.76.13.1.2_L1_Ensure_Configure_Attack_Surface_Reduction_rules_Set_the_state_for_each_ASR_rule_is_configured
  registry_key 'HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Windows Defender Exploit Guard\\ASR\\Rules' do
    values [
      { name: '75668c1f-73b5-4cf0-bb93-3ecf5cb7cc84', type: :dword, data: 1 },
      { name: '3b576869-a4ec-4529-8536-b80a7769e899', type: :dword, data: 1 },
      { name: 'd4f940ab-401b-4efc-aadc-ad5f3c50688a', type: :dword, data: 1 },
      { name: '92e97fa1-2edf-4476-bdd6-9dd0b4dddc7b', type: :dword, data: 1 },
      { name: '5beb7efe-fd9a-4556-801d-275e5ffc04cc', type: :dword, data: 1 },
      { name: 'd3e037e1-3eb8-44c8-a917-57927947596d', type: :dword, data: 1 },
      { name: 'be9ba2d9-53ea-4cdc-84e5-9b1eeee46550', type: :dword, data: 1 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.76.13.3.1_L1_Ensure_Prevent_users_and_apps_from_accessing_dangerous_websites_is_set_to_Enabled_Block
  registry_key 'HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Windows Defender Exploit Guard\\Network Protection' do
    values [{ name: 'EnableNetworkProtection', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.76.14_L1_Ensure_Turn_off_Windows_Defender_AntiVirus_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender' do
    values [{ name: 'DisableAntiSpyware', type: :dword, data: 0 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.76.3.1_L1_Ensure_Configure_local_setting_override_for_reporting_to_Microsoft_MAPS_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Spynet' do
    values [{ name: 'LocalSettingOverrideSpynetReporting', type: :dword, data: 0 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.76.7.1_L1_Ensure_Turn_on_behavior_monitoring_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection' do
    values [{ name: 'DisableBehaviorMonitoring', type: :dword, data: 0 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.79.1.1_L1_Ensure_Prevent_users_from_modifying_settings_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender Security Center\\App and Browser protection' do
    values [{ name: 'DisallowExploitProtectionOverride', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.101.1.1_L1_Ensure_Manage_preview_builds_is_set_to_Enabled_Disable_preview_builds
  # xccdf_org.cisecurity.benchmarks_rule_18.9.101.1.2_L1_Ensure_Select_when_Preview_Builds_and_Feature_Updates_are_received_is_set_to_Enabled_Semi-Annual_Channel_180_or_more_days
  registry_key 'HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate' do
    values [
      { name: 'ManagePreviewBuilds', type: :dword, data: 1 },
      { name: 'ManagePreviewBuildsPolicyValue', type: :dword, data: 0 },
      { name: 'DeferFeatureUpdates', type: :dword, data: 1 },
      { name: 'BranchReadinessLevel', type: :dword, data: 32 },
      { name: 'DeferFeatureUpdatesPeriodInDays', type: :dword, data: 180 },
    ]
    recursive true
    action :create
  end
end

if node['level'] == 2
  # xccdf_org.cisecurity.benchmarks_rule_18.1.3_L2_Ensure_Allow_Online_Tips_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer' do
    values [{ name: 'AllowOnlineTips', type: :dword, data: 0 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.5.5.1_L2_Ensure_Enable_Font_Providers_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\System' do
    values [{ name: 'EnableFontProviders', type: :dword, data: 0 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.16.2_L2_Ensure_Configure_Authenticated_Proxy_usage_for_the_Connected_User_Experience_and_Telemetry_service_is_set_to_Enabled_Disable_Authenticated_Proxy_usage
  registry_key 'HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection' do
    values [{ name: 'DisableEnterpriseAuthProxy', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.84.1_L2_Ensure_Allow_suggested_apps_in_Windows_Ink_Workspace_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\WindowsInkWorkspace' do
    values [{ name: 'AllowSuggestedAppsInWindowsInkWorkspace', type: :dword, data: 0 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.58.3.2.1_L2_Ensure_Restrict_Remote_Desktop_Services_users_to_a_single_Remote_Desktop_Services_session_is_set_to_Enabled
  # xccdf_org.cisecurity.benchmarks_rule_18.9.58.3.3.1_L2_Ensure_Do_not_allow_COM_port_redirection_is_set_to_Enabled
  # xccdf_org.cisecurity.benchmarks_rule_18.9.58.3.3.3_L2_Ensure_Do_not_allow_LPT_port_redirection_is_set_to_Enabled
  # xccdf_org.cisecurity.benchmarks_rule_18.9.58.3.3.4_L2_Ensure_Do_not_allow_supported_Plug_and_Play_device_redirection_is_set_to_Enabled
  # xccdf_org.cisecurity.benchmarks_rule_18.9.58.3.10.1_L2_Ensure_Set_time_limit_for_active_but_idle_Remote_Desktop_Services_sessions_is_set_to_Enabled_15_minutes_or_less
  # xccdf_org.cisecurity.benchmarks_rule_18.9.58.3.10.2_L2_Ensure_Set_time_limit_for_disconnected_sessions_is_set_to_Enabled_1_minute
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows NT\\Terminal Services' do
    values [
      { name: 'fSingleSessionPerUser', type: :dword, data: 1 },
      { name: 'fDisableCcm', type: :dword, data: 1 },
      { name: 'fDisableLPT', type: :dword, data: 1 },
      { name: 'fDisablePNPRedir', type: :dword, data: 1 },
      { name: 'MaxIdleTime', type: :dword, data: 900000 },
      { name: 'MaxDisconnectionTime', type: :dword, data: 60000 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.43.1_L2_Ensure_Allow_Message_Service_Cloud_Sync_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\Messaging' do
    values [
      { name: 'AllowMessageSync', type: :dword, data: 0 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.22.1.2_L2_Ensure_Turn_off_handwriting_personalization_data_sharing_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\TabletPC' do
    values [{ name: 'PreventHandwritingDataSharing', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.22.1.3_L2_Ensure_Turn_off_handwriting_recognition_error_reporting_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\HandwritingErrorReports' do
    values [{ name: 'PreventHandwritingErrorReports', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.22.1.4_L2_Ensure_Turn_off_Internet_Connection_Wizard_if_URL_connection_is_referring_to_Microsoft.com_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\Internet Connection Wizard' do
    values [{ name: 'ExitOnMSICW', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.22.1.7_L2_Ensure_Turn_off_Registration_if_URL_connection_is_referring_to_Microsoft.com_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\Registration Wizard Control' do
    values [{ name: 'NoRegistration', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.22.1.8_L2_Ensure_Turn_off_Search_Companion_content_file_updates_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\SearchCompanion' do
    values [{ name: 'DisableContentFileUpdates', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.22.1.11_L2_Ensure_Turn_off_the_Windows_Messenger_Customer_Experience_Improvement_Program_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Messenger\\Client' do
    values [{ name: 'CEIP', type: :dword, data: 2 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.22.1.12_L2_Ensure_Turn_off_Windows_Customer_Experience_Improvement_Program_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\SQMClient\\Windows' do
    values [{ name: 'CEIPEnable', type: :dword, data: 0 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.4.1_L2_Ensure_Allow_a_Windows_app_to_share_application_data_between_users_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\CurrentVersion\\AppModel\\StateManager' do
    values [{ name: 'AllowSharedLocalAppData', type: :dword, data: 0 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.22.1.13_L2_Ensure_Turn_off_Windows_Error_Reporting_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\Windows Error Reporting' do
    values [{ name: 'Disabled', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  registry_key 'HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\PCHealth\\ErrorReporting' do
    values [{ name: 'DoReport', type: :dword, data: 0 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.25.1_L2_Ensure_Support_device_authentication_using_certificate_is_set_to_Enabled_Automatic
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\\kerberos\\parameters' do
    values [
      { name: 'DevicePKInitBehavior', type: :dword, data: 0 },
      { name: 'DevicePKInitEnabled', type: :dword, data: 1 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.12.1_L2_Ensure_Allow_Use_of_Camera_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Camera' do
    values [{ name: 'AllowCamera', type: :dword, data: 0 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.26.1_L2_Ensure_Disallow_copying_of_user_input_methods_to_the_system_account_for_sign-in_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Control Panel\\International' do
    values [{ name: 'BlockUserInputMethodsForSignIn', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.39.2_L2_Ensure_Turn_off_location_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\LocationAndSensors' do
    values [{ name: 'DisableLocation', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.33.6.1_L2_Ensure_Allow_network_connectivity_during_connected-standby_on_battery_is_set_to_Disabled
  # xccdf_org.cisecurity.benchmarks_rule_18.8.33.6.2_L2_Ensure_Allow_network_connectivity_during_connected-standby_plugged_in_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Power\\PowerSettings\\f15576e8-98b7-4186-b944-eafa664402d9' do
    values [
      { name: 'DCSettingIndex', type: :dword, data: 0 },
      { name: 'ACSettingIndex', type: :dword, data: 0 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.36.2_L2_Ensure_Restrict_Unauthenticated_RPC_clients_is_set_to_Enabled_Authenticated_MS_only
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows NT\\Rpc' do
    values [{ name: 'RestrictRemoteClients', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.44.5.1_L2_Ensure_Microsoft_Support_Diagnostic_Tool_Turn_on_MSDT_interactive_communication_with_support_provider_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\ScriptedDiagnosticsProvider\\Policy' do
    values [{ name: 'DisableQueryRemoteServer', type: :dword, data: 0 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.44.11.1_L2_Ensure_EnableDisable_PerfTrack_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\WDI\\{9c5a40da-b965-4fc3-8781-88dd50a6299d}' do
    values [{ name: 'ScenarioExecutionEnabled', type: :dword, data: 0 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.46.1_L2_Ensure_Turn_off_the_advertising_ID_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\policies\\Microsoft\\Windows\\AdvertisingInfo' do
    values [{ name: 'DisabledByGroupPolicy', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.49.1.1_L2_Ensure_Enable_Windows_NTP_Client_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\W32Time\\TimeProviders\\NtpClient' do
    values [{ name: 'Enabled', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.49.1.2_L2_Ensure_Enable_Windows_NTP_Server_is_set_to_Disabled_MS_only
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\W32Time\\TimeProviders\\NtpServer' do
    values [{ name: 'Enabled', type: :dword, data: 0 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.4.1_L2_Ensure_Allow_a_Windows_app_to_share_application_data_between_users_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\CurrentVersion\\AppModel\\StateManager' do
    values [{ name: 'AllowSharedLocalAppData', type: :dword, data: 0 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.12.1_L2_Ensure_Allow_Use_of_Camera_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Camera' do
    values [{ name: 'AllowCamera', type: :dword, data: 0 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.39.2_L2_Ensure_Turn_off_location_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\LocationAndSensors' do
    values [{ name: 'DisableLocation', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.65.1_L2_Ensure_Turn_off_KMS_Client_Online_AVS_Validation_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows NT\\CurrentVersion\\Software Protection Platform' do
    values [{ name: 'NoGenTicket', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.76.9.1_L2_Ensure_Configure_Watson_events_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows Defender\\Reporting' do
    values [{ name: 'DisableGenericRePorts', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.4.5_L2_Ensure_MSS_KeepAliveTime_How_often_keep-alive_packets_are_sent_in_milliseconds_is_set_to_Enabled_300000_or_5_minutes_recommended
  # xccdf_org.cisecurity.benchmarks_rule_18.4.7_L2_Ensure_MSS_PerformRouterDiscovery_Allow_IRDP_to_detect_and_configure_Default_Gateway_addresses_could_lead_to_DoS_is_set_to_Disabled
  # xccdf_org.cisecurity.benchmarks_rule_18.4.11_L2_Ensure_MSS_TcpMaxDataRetransmissions_How_many_times_unacknowledged_data_is_retransmitted_is_set_to_Enabled_3
  registry_key 'HKEY_LOCAL_MACHINE\\System\\CurrentControlSet\\Services\\Tcpip\\Parameters' do
    values [
      { name: 'KeepAliveTime', type: :dword, data: 300000 },
      { name: 'PerformRouterDiscovery', type: :dword, data: 0 },
      { name: 'tcpmaxdataretransmissions', type: :dword, data: 3 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.4.10_L2_Ensure_MSS_TcpMaxDataRetransmissions_IPv6_How_many_times_unacknowledged_data_is_retransmitted_is_set_to_Enabled_3
  # xccdf_org.cisecurity.benchmarks_rule_18.5.19.2.1_L2_Disable_IPv6_Ensure_TCPIP6_Parameter_DisabledComponents_is_set_to_0xff_255
  registry_key 'HKEY_LOCAL_MACHINE\\System\\CurrentControlSet\\Services\\TCPIP6\\Parameters' do
    values [
      { name: 'tcpmaxdataretransmissions', type: :dword, data: 3 },
      { name: 'DisabledComponents', type: :dword, data: 255 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.5.9.1_L2_Ensure_Turn_on_Mapper_IO_LLTDIO_driver_is_set_to_Disabled
  # xccdf_org.cisecurity.benchmarks_rule_18.5.9.2_L2_Ensure_Turn_on_Responder_RSPNDR_driver_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\LLTD' do
    values [
      { name: 'AllowLLTDIOOndomain', type: :dword, data: 0 },
      { name: 'AllowLLTDIOOnPublicNet', type: :dword, data: 0 },
      { name: 'EnableLLTDIO', type: :dword, data: 0 },
      { name: 'ProhibitLLTDIOOnPrivateNet', type: :dword, data: 0 },
      { name: 'AllowRspndrOndomain', type: :dword, data: 0 },
      { name: 'AllowRspndrOnPublicNet', type: :dword, data: 0 },
      { name: 'EnableRspndr', type: :dword, data: 0 },
      { name: 'ProhibitRspndrOnPrivateNet', type: :dword, data: 0 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.5.10.2_L2_Ensure_Turn_off_Microsoft_Peer-to-Peer_Networking_Services_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Peernet' do
    values [{ name: 'Disabled', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.5.20.1_L2_Ensure_Configuration_of_wireless_settings_using_Windows_Connect_Now_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\WCN\\Registrars' do
    values [
      { name: 'EnableRegistrars', type: :dword, data: 0 },
      { name: 'DisableUPnPRegistrar', type: :dword, data: 0 },
      { name: 'DisableInBand802DOT11Registrar', type: :dword, data: 0 },
      { name: 'DisableFlashConfigRegistrar', type: :dword, data: 0 },
      { name: 'DisableWPDRegistrar', type: :dword, data: 0 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.5.20.2_L2_Ensure_Prohibit_access_of_the_Windows_Connect_Now_wizards_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\WCN\\UI' do
    values [{ name: 'DisableWcnUi', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.5.21.2_L2_Ensure_Prohibit_connection_to_non-domain_networks_when_connected_to_domain_authenticated_network_is_set_to_Enabled_MS_only
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\WcmSvc\\GroupPolicy' do
    values [{ name: 'fBlockNonDomain', type: :dword, data: 1 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.85.3_L2_Ensure_Prevent_Internet_Explorer_security_prompt_for_Windows_Installer_scripts_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\Installer' do
    values [{ name: 'SafeForScripting', type: :dword, data: 0 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.8.22.1.9_L2_Ensure_Turn_off_the_Order_Prints_picture_task_is_set_to_Enabled
  # xccdf_org.cisecurity.benchmarks_rule_18.8.22.1.10_L2_Ensure_Turn_off_the_Publish_to_Web_task_for_files_and_folders_is_set_to_Enabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer' do
    values [
      { name: 'NoOnlinePrintsWizard', type: :dword, data: 1 },
      { name: 'NoPublishingWizard', type: :dword, data: 1 },
    ]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.60.2_L2_Ensure_Allow_Cloud_Search_is_set_to_Enabled_Disable_Cloud_Search
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows\\Windows Search' do
    values [{ name: 'AllowCloudSearch', type: :dword, data: 0 }]
    recursive true
    action :create
  end

  # xccdf_org.cisecurity.benchmarks_rule_18.9.76.3.2_L2_Ensure_Join_Microsoft_MAPS_is_set_to_Disabled
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows Defender\\Spynet' do
    values [{ name: 'SpynetReporting', type: :dword, data: 0 }]
    recursive true
    action :create
  end
end
