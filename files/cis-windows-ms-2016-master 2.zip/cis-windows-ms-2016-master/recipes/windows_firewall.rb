# Cookbook:: cis-windows-ms-2016
# Recipe:: windows_firewall
# Copyright:: 2019, Chef Software, Inc.
# License:: Use of this Software is subject to the terms of the Chef Online Master License and Services Agreement. You can find the latest copy of the agreement here: https://www.chef.io/online-master-agreement

# CIS section 9
return unless platform_family?('windows')

# xccdf_org.cisecurity.benchmarks_rule_9.1.1_L1_Ensure_Windows_Firewall_Domain_Firewall_state_is_set_to_On_recommended
# xccdf_org.cisecurity.benchmarks_rule_9.1.2_L1_Ensure_Windows_Firewall_Domain_Inbound_connections_is_set_to_Block_default
# xccdf_org.cisecurity.benchmarks_rule_9.1.3_L1_Ensure_Windows_Firewall_Domain_Outbound_connections_is_set_to_Allow_default
# xccdf_org.cisecurity.benchmarks_rule_9.1.4_L1_Ensure_Windows_Firewall_Domain_Settings_Display_a_notification_is_set_to_No
registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\WindowsFirewall\\DomainProfile' do
  values [
    { name: 'EnableFirewall', type: :dword, data: 1 },
    { name: 'DefaultInboundAction', type: :dword, data: 1 },
    { name: 'DefaultOutboundAction', type: :dword, data: 0 },
    { name: 'DisableNotifications', type: :dword, data: 1 },
  ]
  recursive true
  action :create
end

# xccdf_org.cisecurity.benchmarks_rule_9.1.5_L1_Ensure_Windows_Firewall_Domain_Logging_Name_is_set_to_SYSTEMROOTSystem32logfilesfirewalldomainfw.log
# xccdf_org.cisecurity.benchmarks_rule_9.1.6_L1_Ensure_Windows_Firewall_Domain_Logging_Size_limit_KB_is_set_to_16384_KB_or_greater
# xccdf_org.cisecurity.benchmarks_rule_9.1.7_L1_Ensure_Windows_Firewall_Domain_Logging_Log_dropped_packets_is_set_to_Yes
# xccdf_org.cisecurity.benchmarks_rule_9.1.8_L1_Ensure_Windows_Firewall_Domain_Logging_Log_successful_connections_is_set_to_Yes
registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\WindowsFirewall\\DomainProfile\\Logging' do
  values [
    { name: 'LogFileSize', type: :dword, data: 16384 },
    { name: 'LogDroppedPackets', type: :dword, data: 1 },
    { name: 'LogSuccessfulConnections', type: :dword, data: 1 },
    { name: 'LogFilePath', type: :string, data: '%systemroot%\\system32\\logfiles\\firewall\\domainfw.log' },
  ]
  recursive true
  action :create
end

# xccdf_org.cisecurity.benchmarks_rule_9.2.1_L1_Ensure_Windows_Firewall_Private_Firewall_state_is_set_to_On_recommended
# xccdf_org.cisecurity.benchmarks_rule_9.2.2_L1_Ensure_Windows_Firewall_Private_Inbound_connections_is_set_to_Block_default
# xccdf_org.cisecurity.benchmarks_rule_9.2.3_L1_Ensure_Windows_Firewall_Private_Outbound_connections_is_set_to_Allow_default
# xccdf_org.cisecurity.benchmarks_rule_9.2.4_L1_Ensure_Windows_Firewall_Private_Settings_Display_a_notification_is_set_to_No
registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\WindowsFirewall\\PrivateProfile' do
  values [
    { name: 'EnableFirewall', type: :dword, data: 1 },
    { name: 'DefaultInboundAction', type: :dword, data: 1 },
    { name: 'DefaultOutboundAction', type: :dword, data: 0 },
    { name: 'DisableNotifications', type: :dword, data: 1 },
  ]
  recursive true
  action :create
end

# xccdf_org.cisecurity.benchmarks_rule_9.2.5_L1_Ensure_Windows_Firewall_Private_Logging_Name_is_set_to_SYSTEMROOTSystem32logfilesfirewallprivatefw.log
# xccdf_org.cisecurity.benchmarks_rule_9.2.6_L1_Ensure_Windows_Firewall_Private_Logging_Size_limit_KB_is_set_to_16384_KB_or_greater
# xccdf_org.cisecurity.benchmarks_rule_9.2.7_L1_Ensure_Windows_Firewall_Private_Logging_Log_dropped_packets_is_set_to_Yes
# xccdf_org.cisecurity.benchmarks_rule_9.2.8_L1_Ensure_Windows_Firewall_Private_Logging_Log_successful_connections_is_set_to_Yes
registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\WindowsFirewall\\PrivateProfile\\Logging' do
  values [
    { name: 'LogFileSize', type: :dword, data: 16384 },
    { name: 'LogDroppedPackets', type: :dword, data: 1 },
    { name: 'LogSuccessfulConnections', type: :dword, data: 1 },
    { name: 'LogFilePath', type: :string, data: '%systemroot%\\system32\\logfiles\\firewall\\privatefw.log' },
  ]
  recursive true
  action :create
end

# xccdf_org.cisecurity.benchmarks_rule_9.3.1_L1_Ensure_Windows_Firewall_Public_Firewall_state_is_set_to_On_recommended
# xccdf_org.cisecurity.benchmarks_rule_9.3.2_L1_Ensure_Windows_Firewall_Public_Inbound_connections_is_set_to_Block_default
# xccdf_org.cisecurity.benchmarks_rule_9.3.3_L1_Ensure_Windows_Firewall_Public_Outbound_connections_is_set_to_Allow_default
# xccdf_org.cisecurity.benchmarks_rule_9.3.4_L1_Ensure_Windows_Firewall_Public_Settings_Display_a_notification_is_set_to_No
# xccdf_org.cisecurity.benchmarks_rule_9.3.6_L1_Ensure_Windows_Firewall_Public_Settings_Apply_local_connection_security_rules_is_set_to_No
registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\WindowsFirewall\\PublicProfile' do
  values [
    { name: 'EnableFirewall', type: :dword, data: 1 },
    { name: 'DefaultInboundAction', type: :dword, data: 1 },
    { name: 'DefaultOutboundAction', type: :dword, data: 0 },
    { name: 'DisableNotifications', type: :dword, data: 1 },
    { name: 'AllowLocalIPsecPolicyMerge', type: :dword, data: 0 },
  ]
  recursive true
  action :create
end

# xccdf_org.cisecurity.benchmarks_rule_9.3.7_L1_Ensure_Windows_Firewall_Public_Logging_Name_is_set_to_SYSTEMROOTSystem32logfilesfirewallpublicfw.log
# xccdf_org.cisecurity.benchmarks_rule_9.3.8_L1_Ensure_Windows_Firewall_Public_Logging_Size_limit_KB_is_set_to_16384_KB_or_greater
# xccdf_org.cisecurity.benchmarks_rule_9.3.9_L1_Ensure_Windows_Firewall_Public_Logging_Log_dropped_packets_is_set_to_Yes
# xccdf_org.cisecurity.benchmarks_rule_9.3.10_L1_Ensure_Windows_Firewall_Public_Logging_Log_successful_connections_is_set_to_Yes
registry_key 'HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\WindowsFirewall\\PublicProfile\\Logging' do
  values [
    { name: 'LogFileSize', type: :dword, data: 16384 },
    { name: 'LogDroppedPackets', type: :dword, data: 1 },
    { name: 'LogSuccessfulConnections', type: :dword, data: 1 },
    { name: 'LogFilePath', type: :string, data: '%systemroot%\\system32\\logfiles\\firewall\\publicfw.log' },
  ]
  recursive true
  action :create
end
