# Cookbook:: cis-windows-ms-2016
# Resource:: windows_audit_policy
# Copyright:: 2019, Chef Software, Inc.
# License:: Use of this Software is subject to the terms of the Chef Online Master License and Services Agreement. You can find the latest copy of the agreement here: https://www.chef.io/online-master-agreement

resource_name 'windows_audit_policy'

description 'The windows_audit_policy resource allows for configuring system and per-user Windows audit policy settings.'

property :category, [String, Array],
         description: 'The audit policy category, specified by GUID or name. Defaults to system if no category is specified.'

property :sub_category, [String, Array],
         description: 'The audit policy subcategory, specified by GUID or name. Defaults to system if no user is specified.'

property :success, [true, false],
         description: 'Specify success auditing. By setting this property to true the resource will enable success for the category or sub category. Success is the default and is applied if neither success nor failure are specified.'

property :failure, [true, false],
         description: 'Specify failure auditing. By setting this property to true the resource will enable failure for the category or sub category. Success is the default and is applied if neither success nor failure are specified.'

property :include_user, String,
         description: 'The audit policy specified by the category or subcategory is applied per-user if specified. When a user is specified, include user. Include and exclude cannot be used at the same time.'

property :exclude_user, String,
         description: 'The audit policy specified by the category or subcategory is applied per-user if specified. When a user is specified, exclude user. Include and exclude cannot be used at the same time.'

property :crash_on_audit_fail, [true, false],
         description: 'Setting this audit policy option to true will cause the system to crash if the auditing system is unable to log events.'

property :full_privilege_auditing, [true, false],
         description: 'Setting this audit policy option to true will force the audit of all privilege changes except SeAuditPrivilege. Setting this property may cause the logs to fill up more quickly.'

property :audit_base_objects, [true, false],
         description: 'Setting this audit policy option to true will force the system to assign a System Access Control List to named objects to enable auditing of base objects such as mutexes.'

property :audit_base_directories, [true, false],
         description: 'Setting this audit policy option to true will force the system to assign a System Access Control List to named objects to enable auditing of container objects such as directories.'

action :set do
  unless exists?
    success_value = new_resource.success ? 'Enable' : 'Disable'
    failure_value = new_resource.failure ? 'Enable' : 'Disable'
    crash_on_audit_fail_value = new_resource.crash_on_audit_fail ? 'Enable' : 'Disable'
    full_privilege_auditing_value = new_resource.full_privilege_auditing ? 'Enable' : 'Disable'
    audit_base_objects_value = new_resource.audit_base_objects ? 'Enable' : 'Disable'
    audit_base_directories_value = new_resource.audit_base_directories ? 'Enable' : 'Disable'
    cmd = 'AuditPol'
    cmd << ' /Set'

    if !new_resource.crash_on_audit_fail.nil?
      cmd << ' /Option:CrashOnAuditFail'
      cmd << " /Value:#{crash_on_audit_fail_value}"
    elsif !new_resource.full_privilege_auditing.nil?
      cmd << ' /Option:FullPrivilegeAuditing'
      cmd << " /Value:#{full_privilege_auditing_value}"
    elsif !new_resource.audit_base_objects.nil?
      cmd << ' /Option:AuditBaseObjects'
      cmd << " /Value:#{audit_base_objects_value}"
    elsif !new_resource.audit_base_directories.nil?
      cmd << ' /Option:AuditBaseDirectories'
      cmd << " /Value:#{audit_base_directories_value}"
    else
      cmd << " /User:\"#{new_resource.include_user}\" /Include" if new_resource.include_user
      cmd << " /User:\"#{new_resource.exclude_user}\" /Exclude" if new_resource.exclude_user
      cmd << " /Category:\"#{new_resource.category}\"" unless new_resource.category.nil?
      cmd << if new_resource.sub_category.is_a?(Array)
               " /SubCategory:'#{new_resource.sub_category.join("','")}'"
             else
               " /SubCategory:\"#{new_resource.sub_category}\""
             end
      cmd << " /Success:#{success_value}"
      cmd << " /Failure:#{failure_value}"
    end

    message = 'Setting Audit Policy'

    powershell_script message.to_s do
      code cmd
    end
  end
end

action_class do
  def exists?
    setting = ''
    if new_resource.success && new_resource.failure
      setting = 'Success and Failure'
    elsif new_resource.success
      setting = 'Success'
    elsif new_resource.failure
      setting = 'Failure'
    else
      Chef::Log.warn('You have not specified an audit criteria.')
      setting = 'No Auditing'
    end

    cmd =  '(AuditPol'
    cmd << ' /Get'
    cmd << " /User:\\\"#{new_resource.include_user}\\\"" if new_resource.include_user
    cmd << " /User:\\\"#{new_resource.exclude_user}\\\"" if new_resource.exclude_user
    cmd << " /Category:\"#{new_resource.category}\"" unless new_resource.category.nil?
    cmd << " /SubCategory:\\\"#{new_resource.sub_category}\\\""
    cmd << ' /Option:CrashOnAuditFail' unless new_resource.crash_on_audit_fail.nil?
    cmd << ' /Option:FullPrivilegeAuditing' unless new_resource.full_privilege_auditing.nil?
    cmd << ' /Option:AuditBaseObjects' unless new_resource.audit_base_objects.nil?
    cmd << ' /Option:AuditBaseDirectories' unless new_resource.audit_base_directories.nil?
    cmd << ' /r)'
    cmd << "[2].split(\\\",\\\")[4] -eq \\\"#{setting}\\\""
    check = Mixlib::ShellOut.new("powershell.exe -command #{cmd}").run_command
    check.stdout.match('True')
  end
end
