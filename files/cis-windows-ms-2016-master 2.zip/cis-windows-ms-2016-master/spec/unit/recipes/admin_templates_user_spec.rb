# Cookbook:: cis-windows-ms-2016
# Spec:: admin_templates_user
# Copyright:: 2019, Chef Software, Inc.
# License:: Use of this Software is subject to the terms of the Chef Online Master License and Services Agreement. You can find the latest copy of the agreement here: https://www.chef.io/online-master-agreement

# CIS section 19
require 'spec_helper'

describe 'cis-windows-ms-2016::admin_templates_user' do
  let(:chef_run) do
    allow_any_instance_of(Chef::DSL::RegistryHelper).to receive(:registry_get_subkeys).with('HKEY_USERS', ':x86_64').and_return(['S-1-5-21-1-1-1-500'])
    runner = ChefSpec::ServerRunner.new(platform: 'windows', version: '2016')
    runner.converge(described_recipe)
  end

  it 'converges successfully' do
    expect { chef_run }.to_not raise_error
  end

  it 'creates registry key with expected values' do
    expect(chef_run).to create_registry_key('HKU\\S-1-5-21-1-1-1-500\\Software\\Policies\\Microsoft\\Windows\\Control Panel\\Desktop')
      .with(unscrubbed_values: [{ name: 'SCRNSAVE.EXE', type: :string, data: 'scrnsave.scr' },
                                { name: 'ScreenSaverIsSecure', type: :string, data: '1' },
                                { name: 'ScreenSaveActive', type: :string, data: '1' },
                                { name: 'ScreenSaveTimeOut', type: :dword, data: 900 }], recursive: true)
  end
end
