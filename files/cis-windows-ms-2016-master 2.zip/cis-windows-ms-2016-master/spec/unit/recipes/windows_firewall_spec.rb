# Cookbook:: cis-windows-ms-2016
# Spec:: windows_firewall
# Copyright:: 2019, Chef Software, Inc.
# License:: Use of this Software is subject to the terms of the Chef Online Master License and Services Agreement. You can find the latest copy of the agreement here: https://www.chef.io/online-master-agreement

# CIS section 9
require 'spec_helper'

describe 'cis-windows-ms-2016::windows_firewall' do
  let(:chef_run) do
    runner = ChefSpec::ServerRunner.new(platform: 'windows', version: '2016')
    runner.converge(described_recipe)
  end

  it 'converges successfully' do
    expect { chef_run }.to_not raise_error
  end

  it 'creates registry key with expected value' do
    expect(chef_run).to create_registry_key('HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\WindowsFirewall\\DomainProfile')
      .with(unscrubbed_values: [{ name: 'EnableFirewall', type: :dword, data: 1 },
                                { name: 'DefaultInboundAction', type: :dword, data: 1 },
                                { name: 'DefaultOutboundAction', type: :dword, data: 0 },
                                { name: 'DisableNotifications', type: :dword, data: 1 }], recursive: true)
  end
end
