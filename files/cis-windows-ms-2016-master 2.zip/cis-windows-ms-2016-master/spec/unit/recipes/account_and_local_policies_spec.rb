# Cookbook:: cis-windows-ms-2016
# Spec:: account_and_local_policies
# Copyright:: 2019, Chef Software, Inc.
# License:: Use of this Software is subject to the terms of the Chef Online Master License and Services Agreement. You can find the latest copy of the agreement here: https://www.chef.io/online-master-agreement

# CIS section 1 and 2
require 'spec_helper'

describe 'cis-windows-ms-2016::account_and_local_policies' do
  let(:chef_run) do
    runner = ChefSpec::ServerRunner.new(platform: 'windows', version: '2016')
    runner.converge(described_recipe)
  end

  let(:node) { chef_run.node }

  it 'converges successfully' do
    expect { chef_run }.to_not raise_error
  end

  it 'sets the attribute value correctly' do
    allow(Mixlib::ShellOut).to receive(:shell_out).with('powershell.exe -command Import-module servermanager ; (Get-WindowsFeature Web-Server).Installed').and_return(true)
    node.default['IIS'] == true
  end

  it 'creates template from policy.inf.erb' do
    expect(chef_run).to create_template('c:/windows/temp/win2016_account_and_local_policies.inf')
  end

  it 'creates registry key with expected values' do
    expect(chef_run).to create_registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Print\\Providers\\LanMan Print Services\\Servers')
      .with(unscrubbed_values: [{ name: 'AddPrinterDrivers', type: :dword, data: 1 }], recursive: true)
  end
end
