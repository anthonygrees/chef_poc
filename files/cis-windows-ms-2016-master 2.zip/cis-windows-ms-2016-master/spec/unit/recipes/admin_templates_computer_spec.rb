# Cookbook:: cis-windows-ms-2016
# Spec:: admin_templates_computer
# Copyright:: 2019, Chef Software, Inc.
# License:: Use of this Software is subject to the terms of the Chef Online Master License and Services Agreement. You can find the latest copy of the agreement here: https://www.chef.io/online-master-agreement

# CIS section 18
require 'spec_helper'

describe 'cis-windows-ms-2016::admin_templates_computer' do
  let(:runner) { ChefSpec::ServerRunner.new(platform: 'windows', version: '2016') }
  let(:chef_run) { runner.converge(described_recipe) }

  it 'converges successfully' do
    expect { chef_run }.to_not raise_error
  end

  it 'creates a registry key with expected values' do
    expect(chef_run).to create_registry_key('HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\InputPersonalization')
      .with(unscrubbed_values: [{ name: 'AllowInputPersonalization', type: :dword, data: 0 }], recursive: true)
  end
end
