# Policyfile.rb - Describe how you want Chef to build your system.
#
# For more information on the Policyfile feature, visit
# https://docs.chef.io/policyfile.html

# A name that describes what the system you're building with Chef does.
name 'cis-windows-ms-2016'

# Where to find external cookbooks:
default_source :supermarket

# run_list: chef-client will run these recipes in the order specified.
run_list 'test::laps', 'cis-windows-ms-2016::default'
named_run_list :iis, 'test::iis', 'cis-windows-ms-2016::default'
named_run_list :hyperv, 'test::hyperv', 'cis-windows-ms-2016::default'
named_run_list :windows_audit_policy_resource, 'test::windows_audit_policy_resource'

# Specify a custom source for a single cookbook:
cookbook 'cis-windows-ms-2016', path: '.'
cookbook 'test', path: 'test/cookbooks/test'
