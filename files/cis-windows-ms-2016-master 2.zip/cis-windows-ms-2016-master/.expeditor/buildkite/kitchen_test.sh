#!/bin/bash

set -eou pipefail

: ${KITCHEN_SUITE?"KITCHEN_SUITE must be set in environment"}
: ${COOKBOOK_GLOB?"COOKBOOK_GLOB must be set in environment"}

if $(did-modify --globs=$COOKBOOK_GLOB --git_ref=origin/master); then
  aws-configure chef-cd
  configure-github-account chef-ci
  aws --profile chef-cd s3 cp s3://chef-cd-citadel/aws-accounts/partner-engineering/ComplianceProfiles.pem ~/.ssh/ComplianceProfiles.pem
  chmod 0600 ~/.ssh/ComplianceProfiles.pem
  
  chef gem install bundler
  chef exec bundle install --without development --path vendor/bundle
  
  kitchen test $KITCHEN_SUITE -d
else
  echo "Not executing kitchen testing as there were no changes to recipes or resources."
fi
