#!/bin/bash

set +x

echo
echo 'Confirm ruby versions and ensure ruby setup is clean'
echo
gem env
echo
gem install bundler --no-rdoc
echo
bundle -v
echo
chef -v
echo
echo 'Remove old bundler files'
rm -f Gemfile.lock
echo
rm -rf .bundle
