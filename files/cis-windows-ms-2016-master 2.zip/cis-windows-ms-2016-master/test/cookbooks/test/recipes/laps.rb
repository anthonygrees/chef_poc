windows_package 'Local Administrator Password Solution' do
  source 'https://download.microsoft.com/download/C/7/A/C7AAD914-A8A6-4904-88A1-29E657445D03/LAPS.x64.msi'
  checksum 'f63ebbc45e2d080630bd62a195cd225de734131a56bb7b453c84336e37abd766'
end
