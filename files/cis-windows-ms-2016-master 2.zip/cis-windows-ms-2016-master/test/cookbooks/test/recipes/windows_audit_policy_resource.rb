# testing windows_audit_policy resource

windows_audit_policy 'Credential Validation Success & Failure' do
  action :set
  sub_category 'Credential Validation'
  success true
  failure true
end

windows_audit_policy "Audit 'Application Group Management', 'Computer Account Management', 'Other Account Management Events'" do
  action :set
  sub_category ['Application Group Management', 'Computer Account Management', 'Other Account Management Events']
  success true
  failure true
end

windows_audit_policy "Audit 'Process Creation', 'Group Membership', 'Logoff'" do
  action :set
  sub_category ['Process Creation', 'Group Membership', 'Logoff']
  success true
end

windows_audit_policy 'Plug and Play Events Success' do
  action :set
  sub_category 'Plug and Play Events'
  success true
end

windows_audit_policy 'Account Lockout Failure' do
  action :set
  sub_category 'Account Lockout'
  failure true
end

windows_audit_policy 'Set category and subcategory' do
  action :set
  category 'System'
  sub_category 'Security State Change'
  failure true
end

windows_audit_policy 'Enable CrashOnAuditFail Option' do
  action :set
  crash_on_audit_fail true
end

windows_audit_policy 'Disable CrashOnAuditFail Option' do
  action :set
  crash_on_audit_fail false
end

windows_audit_policy 'Enable FullPrivilegeAuditing Option' do
  action :set
  full_privilege_auditing true
end

windows_audit_policy 'Disable FullPrivilegeAuditing Option' do
  action :set
  full_privilege_auditing false
end

windows_audit_policy 'Enable AuditBaseObjects Option' do
  action :set
  audit_base_objects true
end

windows_audit_policy 'Disable AuditBaseObjects Option' do
  action :set
  audit_base_objects false
end

windows_audit_policy 'Enable AuditBaseDirectories Option' do
  action :set
  audit_base_directories true
end

windows_audit_policy 'Disable AuditBaseDirectories Option' do
  action :set
  audit_base_directories false
end

windows_audit_policy 'Exclude User' do
  action :set
  exclude_user 'Guest'
  sub_category 'Account Lockout'
  success true
  failure true
end

windows_audit_policy 'Include User' do
  action :set
  include_user 'Guest'
  sub_category 'Credential Validation'
  success true
end
