windows_feature_powershell 'Hyper-V' do
  action :install
end
