windows_feature_powershell 'Web-Server' do
  action :install
end
