# Cookbook:: cis-windows-ms-2016
# Spec:: windows_audit_policy
# Copyright:: 2019, Chef Software, Inc.
# License:: Use of this Software is subject to the terms of the Chef Online Master License and Services Agreement. You can find the latest copy of the agreement here: https://www.chef.io/online-master-agreement

describe audit_policy do
  its('Credential Validation') { should eq 'Success and Failure' }
end

describe audit_policy do
  its('Plug and Play Events') { should eq 'Success' }
end

describe audit_policy do
  its('Account Lockout') { should eq 'Failure' }
end

describe audit_policy do
  its('Security State Change') { should eq 'Failure' }
end
