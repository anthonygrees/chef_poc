# Windows 2016 Member Server Remediation Cookbook

Cookbook for hardening a Windows 2016 Member Server to be compliant with CIS Microsoft Windows Server 2016 RTM (Release 1607) Benchmark Level 1 and Level 2 - Member Server.

## Requirements

### Platforms

- Windows Server 2016 Member Server

## Unremediated CIS Controls

The following controls are not remediated within the scope of this cookbook as they affect the ability to remotely access the remediated machine. These controls should be implemented in accordance with your site policy.

- 2.2.21 - Ensure 'Deny access to this computer from the network' is set to 'Guests, Local account and member of Administrators group' (MS only)
- 2.2.26 - Ensure 'Deny log on through Remote Desktop Services' is set to 'Guests, Local account' (MS only)
- 2.3.1.1 - Ensure 'Accounts: Administrator account status' is set to 'Disabled'
- 2.3.1.5 - Configure 'Accounts: Rename administrator account'
- 2.3.17.1 - Ensure 'User Account Control: Admin Approval Mode for the Built-in Administrator account' is set to 'Enabled'
- 9.3.5 - Ensure 'Windows Firewall: Public: Settings: Apply local firewall rules' is set to 'No'
- 18.9.97.2.2 - Ensure 'Allow remote server management through WinRM' is set to 'Disabled'
- 18.9.98.1 - Ensure 'Allow Remote Shell Access' is set to 'Disabled'

The following controls are not remediated within the scope of this cookbook as they concern text displayed to users when they log on. These controls should be implemented in accordance with your site policy. Example code has been provided below.

- 2.3.7.4 - Configure 'Interactive logon: Message text for users attempting to log on'
- 2.3.7.5 - Configure 'Interactive logon: Message title for users attempting to log on'

```ruby
  # xccdf_org.cisecurity.benchmarks_rule_2.3.7.4_L1_Configure_Interactive_logon_Message_text_for_users_attempting_to_log_on
  # xccdf_org.cisecurity.benchmarks_rule_2.3.7.5_L1_Configure_Interactive_logon_Message_title_for_users_attempting_to_log_on
  registry_key 'HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' do
    values [
      { name: 'LegalNoticeCaption', type: :string, data: 'Legal notice caption here' },
      { name: 'LegalNoticeText', type: :string, data: 'Legal notice text here' },
    ]
    recursive true
    action :create
  end
```

## CIS Profile Version

This cookbook is tested using Chef's InSpec compliance profile CIS Windows 2016 Release 1607 Level 2 Member Server v1.1.0.

## Notes

The following tools are not installed by this cookbook, but are recommended by CIS:
- Local Administrator Password Solution (LAPS). The remediation relating to LAPS is applied only if the `AdmPwd.dll` required by LAPS is found on the system. See [here](https://www.microsoft.com/en-us/download/details.aspx?id=46899) for more information.
- Internet Information Services (IIS). Related remediation is applied only if IIS is installed. See [here](https://www.iis.net/) for more information.
- Hyper-V. Related remediation is applied only if Hyper-V is installed.