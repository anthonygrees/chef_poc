# This recipe contains resources to bring test-kitchen specific aspects of the node into compliance.
# It is designed to only be run when the recipe is run inside test-kitchen

if ENV['TEST_KITCHEN']

  # Changes for Virtualbox
  # xccdf_org.cisecurity.benchmarks_rule_5.4.2_Ensure_system_accounts_are_non-login
  user 'vboxadd' do
    shell '/sbin/nologin'
  end

  # xccdf_org.cisecurity.benchmarks_rule_6.2.7_Ensure_all_users_home_directories_exist
  directory '/var/run/vboxadd' do
    user 'vboxadd'
    mode '0700'
  end

  directory '/var/ftp' do
    user 'ftp'
    mode '0700'
  end

  # xccdf_org.cisecurity.benchmarks_rule_1.1.18_Ensure_sticky_bit_is_set_on_all_world-writable_directories
  directory '/tmp/omnibus/cache' do
    mode '01777'
  end

  # xccdf_org.cisecurity.benchmarks_rule_6.1.10_Ensure_no_world_writable_files_exist
  execute 'Remove_cached_rpms' do
    command 'rm -f /tmp/omnibus/cache/*.rpm'
  end
end
