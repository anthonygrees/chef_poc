name             'cis-rhel'
maintainer       'Chef Software, Inc.'
maintainer_email 'cookbooks@chef.io'
license          'Proprietary - All Rights Reserved'
description      'Installs/Configures cis-rhel'
version          '0.3.1'
chef_version     '>= 13.1'

source_url 'https://github.com/chef/cis-rhel'
issues_url 'https://github.com/chef/cis-rhel/issues'

supports 'redhat', '>= 6.7'
supports 'centos', '>= 6.7'

depends 'firewall', '~> 2.7'
depends 'ntp', '~> 3.5'
depends 'rsyslog', '~> 6.0'
depends 'line', '~> 2.0.2'
